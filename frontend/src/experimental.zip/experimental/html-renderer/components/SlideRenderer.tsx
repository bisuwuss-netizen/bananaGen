/**
 * 幻灯片渲染器组件
 * 根据布局ID动态渲染对应的布局组件
 */

import React from 'react';
import {
  PagePayload,
  ThemeConfig,
  CoverModel,
  TocModel,
  TitleContentModel,
  TitleBulletsModel,
  TwoColumnModel,
  ProcessStepsModel,
  EndingModel,
  SectionTitleModel,
  ImageFullModel,
  QuoteModel,
} from '../types/schema';
import { CoverLayout } from '../layouts/CoverLayout';
import { TocLayout } from '../layouts/TocLayout';
import { TitleContentLayout } from '../layouts/TitleContentLayout';
import { TitleBulletsLayout } from '../layouts/TitleBulletsLayout';
import { TwoColumnLayout } from '../layouts/TwoColumnLayout';
import { ProcessStepsLayout } from '../layouts/ProcessStepsLayout';
import { EndingLayout } from '../layouts/EndingLayout';
import { SectionTitleLayout } from '../layouts/SectionTitleLayout';
import { ImageFullLayout } from '../layouts/ImageFullLayout';
import { QuoteLayout } from '../layouts/QuoteLayout';

interface SlideRendererProps {
  page: PagePayload;
  theme: ThemeConfig;
  scale?: number;
  onClick?: () => void;
  isSelected?: boolean;
}

export const SlideRenderer: React.FC<SlideRendererProps> = ({
  page,
  theme,
  scale = 1,
  onClick,
  isSelected = false,
}) => {
  const { layout_id, model } = page;

  const containerStyle: React.CSSProperties = {
    transform: `scale(${scale})`,
    transformOrigin: 'top left',
    width: theme.sizes.slideWidth,
    height: theme.sizes.slideHeight,
    boxShadow: isSelected
      ? `0 0 0 4px ${theme.colors.accent}, 0 4px 20px rgba(0,0,0,0.15)`
      : '0 4px 20px rgba(0,0,0,0.1)',
    borderRadius: '4px',
    overflow: 'hidden',
    cursor: onClick ? 'pointer' : 'default',
    transition: 'box-shadow 0.2s ease',
  };

  const renderLayout = () => {
    switch (layout_id) {
      case 'cover':
        return <CoverLayout model={model as CoverModel} theme={theme} />;
      case 'toc':
        return <TocLayout model={model as TocModel} theme={theme} />;
      case 'title_content':
        return <TitleContentLayout model={model as TitleContentModel} theme={theme} />;
      case 'title_bullets':
        return <TitleBulletsLayout model={model as TitleBulletsModel} theme={theme} />;
      case 'two_column':
        return <TwoColumnLayout model={model as TwoColumnModel} theme={theme} />;
      case 'process_steps':
        return <ProcessStepsLayout model={model as ProcessStepsModel} theme={theme} />;
      case 'ending':
        return <EndingLayout model={model as EndingModel} theme={theme} />;
      case 'section_title':
        return <SectionTitleLayout model={model as SectionTitleModel} theme={theme} />;
      case 'image_full':
        return <ImageFullLayout model={model as ImageFullModel} theme={theme} />;
      case 'quote':
        return <QuoteLayout model={model as QuoteModel} theme={theme} />;
      default:
        return (
          <div
            style={{
              width: theme.sizes.slideWidth,
              height: theme.sizes.slideHeight,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: '#f0f0f0',
              color: '#666',
            }}
          >
            未知布局类型: {layout_id}
          </div>
        );
    }
  };

  return (
    <div style={containerStyle} onClick={onClick}>
      {renderLayout()}
    </div>
  );
};

export default SlideRenderer;
