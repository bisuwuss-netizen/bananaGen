/**
 * 流程步骤布局组件
 */

import React from 'react';
import { ProcessStepsModel, ThemeConfig } from '../types/schema';
import {
  toInlineStyle,
  getBaseSlideStyle,
  getTitleStyle,
  getSubtitleStyle,
} from '../utils/styleHelper';

interface ProcessStepsLayoutProps {
  model: ProcessStepsModel;
  theme: ThemeConfig;
}

export const ProcessStepsLayout: React.FC<ProcessStepsLayoutProps> = ({ model, theme }) => {
  const { title, subtitle, steps } = model;

  const slideStyle = toInlineStyle(getBaseSlideStyle(theme));
  const titleStyle = toInlineStyle(getTitleStyle(theme));
  const subtitleStyle = toInlineStyle(getSubtitleStyle(theme));

  const stepsContainerStyle = toInlineStyle({
    marginTop: '50px',
    display: 'flex',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: '20px',
    position: 'relative',
  });

  // 连接线样式
  const connectorStyle = toInlineStyle({
    position: 'absolute',
    top: '40px',
    left: '80px',
    right: '80px',
    height: '4px',
    backgroundColor: theme.colors.backgroundAlt,
    zIndex: '0',
  });

  return (
    <section style={parseStyle(slideStyle)}>
      <h2 style={parseStyle(titleStyle)}>{title}</h2>
      {subtitle && <p style={parseStyle(subtitleStyle)}>{subtitle}</p>}
      <div style={parseStyle(stepsContainerStyle)}>
        <div style={parseStyle(connectorStyle)} />
        {steps.map((step, index) => (
          <StepCard key={index} step={step} theme={theme} isLast={index === steps.length - 1} />
        ))}
      </div>
    </section>
  );
};

const StepCard: React.FC<{
  step: { number: number; label: string; description?: string; icon?: string };
  theme: ThemeConfig;
  isLast: boolean;
}> = ({ step, theme }) => {
  const cardStyle = toInlineStyle({
    flex: '1',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    textAlign: 'center',
    position: 'relative',
    zIndex: '1',
  });

  const circleStyle = toInlineStyle({
    width: '80px',
    height: '80px',
    borderRadius: '50%',
    backgroundColor: theme.colors.secondary,
    color: '#ffffff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '28px',
    fontWeight: 'bold',
    marginBottom: '20px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
  });

  const labelStyle = toInlineStyle({
    fontSize: '20px',
    fontWeight: '600',
    color: theme.colors.text,
    margin: '0',
  });

  const descriptionStyle = toInlineStyle({
    fontSize: '14px',
    color: theme.colors.textLight,
    margin: '0',
    marginTop: '8px',
    lineHeight: '1.4',
    maxWidth: '150px',
  });

  return (
    <div style={parseStyle(cardStyle)}>
      <div style={parseStyle(circleStyle)}>
        {step.icon ? (
          <i className={step.icon.startsWith('fa') ? step.icon : `fa ${step.icon}`} />
        ) : (
          step.number
        )}
      </div>
      <p style={parseStyle(labelStyle)}>{step.label}</p>
      {step.description && (
        <p style={parseStyle(descriptionStyle)}>{step.description}</p>
      )}
    </div>
  );
};

export function renderProcessStepsLayoutHTML(model: ProcessStepsModel, theme: ThemeConfig): string {
  const { title, subtitle, steps } = model;

  const slideStyle = toInlineStyle({
    width: `${theme.sizes.slideWidth}px`,
    height: `${theme.sizes.slideHeight}px`,
    position: 'relative',
    overflow: 'hidden',
    fontFamily: theme.fonts.body,
    color: theme.colors.text,
    backgroundColor: theme.colors.background,
    boxSizing: 'border-box',
    padding: theme.spacing.padding,
  });

  const titleStyle = toInlineStyle({
    fontSize: theme.sizes.titleSize,
    fontWeight: 'bold',
    color: theme.colors.primary,
    margin: '0',
    lineHeight: '1.3',
    fontFamily: theme.fonts.title,
  });

  const subtitleStyle = toInlineStyle({
    fontSize: theme.sizes.subtitleSize,
    color: theme.colors.textLight,
    margin: '0',
    marginTop: '12px',
    lineHeight: '1.4',
  });

  const stepsContainerStyle = toInlineStyle({
    marginTop: '50px',
    display: 'flex',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: '20px',
    position: 'relative',
  });

  const connectorStyle = toInlineStyle({
    position: 'absolute',
    top: '40px',
    left: '80px',
    right: '80px',
    height: '4px',
    backgroundColor: theme.colors.backgroundAlt,
    zIndex: '0',
  });

  const stepsHTML = steps
    .map((step) => {
      const cardStyle = toInlineStyle({
        flex: '1',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        textAlign: 'center',
        position: 'relative',
        zIndex: '1',
      });

      const circleStyle = toInlineStyle({
        width: '80px',
        height: '80px',
        borderRadius: '50%',
        backgroundColor: theme.colors.secondary,
        color: '#ffffff',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '28px',
        fontWeight: 'bold',
        marginBottom: '20px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
      });

      const labelStyle = toInlineStyle({
        fontSize: '20px',
        fontWeight: '600',
        color: theme.colors.text,
        margin: '0',
      });

      const descriptionStyle = toInlineStyle({
        fontSize: '14px',
        color: theme.colors.textLight,
        margin: '0',
        marginTop: '8px',
        lineHeight: '1.4',
        maxWidth: '150px',
      });

      const iconClass = step.icon
        ? step.icon.startsWith('fa') ? step.icon : `fa ${step.icon}`
        : '';
      const circleContent = iconClass
        ? `<i class="${iconClass}"></i>`
        : String(step.number);

      return `<div style="${cardStyle}">
      <div style="${circleStyle}">${circleContent}</div>
      <p style="${labelStyle}">${step.label}</p>
      ${step.description ? `<p style="${descriptionStyle}">${step.description}</p>` : ''}
    </div>`;
    })
    .join('\n    ');

  return `<section style="${slideStyle}">
  <h2 style="${titleStyle}">${title}</h2>
  ${subtitle ? `<p style="${subtitleStyle}">${subtitle}</p>` : ''}
  <div style="${stepsContainerStyle}">
    <div style="${connectorStyle}"></div>
    ${stepsHTML}
  </div>
</section>`;
}

function parseStyle(styleString: string): React.CSSProperties {
  const styles: Record<string, string> = {};
  styleString.split(';').forEach((rule) => {
    const [key, value] = rule.split(':').map((s) => s.trim());
    if (key && value) {
      const camelKey = key.replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
      styles[camelKey] = value;
    }
  });
  return styles as React.CSSProperties;
}

export default ProcessStepsLayout;
