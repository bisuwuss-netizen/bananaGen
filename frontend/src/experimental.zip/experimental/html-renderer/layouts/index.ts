/**
 * 布局组件导出
 */

export { CoverLayout, renderCoverLayoutHTML } from './CoverLayout';
export { TocLayout, renderTocLayoutHTML } from './TocLayout';
export { TitleContentLayout, renderTitleContentLayoutHTML } from './TitleContentLayout';
export { TitleBulletsLayout, renderTitleBulletsLayoutHTML } from './TitleBulletsLayout';
export { TwoColumnLayout, renderTwoColumnLayoutHTML } from './TwoColumnLayout';
export { ProcessStepsLayout, renderProcessStepsLayoutHTML } from './ProcessStepsLayout';
export { EndingLayout, renderEndingLayoutHTML } from './EndingLayout';
export { SectionTitleLayout, renderSectionTitleLayoutHTML } from './SectionTitleLayout';
export { ImageFullLayout, renderImageFullLayoutHTML } from './ImageFullLayout';
export { QuoteLayout, renderQuoteLayoutHTML } from './QuoteLayout';

import { LayoutId, LayoutModel, ThemeConfig } from '../types/schema';
import { renderCoverLayoutHTML } from './CoverLayout';
import { renderTocLayoutHTML } from './TocLayout';
import { renderTitleContentLayoutHTML } from './TitleContentLayout';
import { renderTitleBulletsLayoutHTML } from './TitleBulletsLayout';
import { renderTwoColumnLayoutHTML } from './TwoColumnLayout';
import { renderProcessStepsLayoutHTML } from './ProcessStepsLayout';
import { renderEndingLayoutHTML } from './EndingLayout';
import { renderSectionTitleLayoutHTML } from './SectionTitleLayout';
import { renderImageFullLayoutHTML } from './ImageFullLayout';
import { renderQuoteLayoutHTML } from './QuoteLayout';

/**
 * 根据布局ID渲染HTML字符串
 */
export function renderLayoutHTML(
  layoutId: LayoutId,
  model: LayoutModel,
  theme: ThemeConfig
): string {
  switch (layoutId) {
    case 'cover':
      return renderCoverLayoutHTML(model as any, theme);
    case 'toc':
      return renderTocLayoutHTML(model as any, theme);
    case 'title_content':
      return renderTitleContentLayoutHTML(model as any, theme);
    case 'title_bullets':
      return renderTitleBulletsLayoutHTML(model as any, theme);
    case 'two_column':
      return renderTwoColumnLayoutHTML(model as any, theme);
    case 'process_steps':
      return renderProcessStepsLayoutHTML(model as any, theme);
    case 'ending':
      return renderEndingLayoutHTML(model as any, theme);
    case 'section_title':
      return renderSectionTitleLayoutHTML(model as any, theme);
    case 'image_full':
      return renderImageFullLayoutHTML(model as any, theme);
    case 'quote':
      return renderQuoteLayoutHTML(model as any, theme);
    default:
      console.warn(`Unknown layout: ${layoutId}`);
      return `<section style="width:1280px;height:720px;display:flex;align-items:center;justify-content:center;background:#f0f0f0;">
        <p style="color:#666;">未知布局类型: ${layoutId}</p>
      </section>`;
  }
}

/**
 * 布局ID到名称的映射
 */
export const layoutNames: Record<LayoutId, string> = {
  cover: '封面页',
  toc: '目录页',
  title_content: '标题+正文',
  title_bullets: '标题+要点',
  two_column: '左右双栏',
  process_steps: '流程步骤',
  ending: '结束页',
  section_title: '章节标题',
  image_full: '全图页',
  quote: '引用页',
};
