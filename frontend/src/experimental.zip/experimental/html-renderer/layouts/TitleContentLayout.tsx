/**
 * 标题+正文布局组件
 */

import React from 'react';
import { TitleContentModel, ThemeConfig } from '../types/schema';
import {
  toInlineStyle,
  getBaseSlideStyle,
  getTitleStyle,
  getBodyStyle,
} from '../utils/styleHelper';

interface TitleContentLayoutProps {
  model: TitleContentModel;
  theme: ThemeConfig;
}

export const TitleContentLayout: React.FC<TitleContentLayoutProps> = ({ model, theme }) => {
  const { title, content, highlight } = model;

  const slideStyle = toInlineStyle(getBaseSlideStyle(theme));
  const titleStyle = toInlineStyle(getTitleStyle(theme));

  const contentContainerStyle = toInlineStyle({
    marginTop: '40px',
    flex: '1',
  });

  const paragraphStyle = toInlineStyle({
    ...getBodyStyle(theme),
    marginTop: '20px',
  });

  const highlightStyle = toInlineStyle({
    marginTop: '30px',
    padding: '20px 24px',
    backgroundColor: theme.colors.backgroundAlt,
    borderLeft: `4px solid ${theme.colors.accent}`,
    borderRadius: '0 8px 8px 0',
    fontSize: theme.sizes.bodySize,
    color: theme.colors.text,
    fontStyle: 'italic',
  });

  const contentArray = Array.isArray(content) ? content : [content];

  return (
    <section style={parseStyle(slideStyle)}>
      <h2 style={parseStyle(titleStyle)}>{title}</h2>
      <div style={parseStyle(contentContainerStyle)}>
        {contentArray.map((paragraph, index) => (
          <p key={index} style={parseStyle(paragraphStyle)}>
            {paragraph}
          </p>
        ))}
        {highlight && (
          <div style={parseStyle(highlightStyle)}>{highlight}</div>
        )}
      </div>
    </section>
  );
};

export function renderTitleContentLayoutHTML(model: TitleContentModel, theme: ThemeConfig): string {
  const { title, content, highlight } = model;

  const slideStyle = toInlineStyle({
    width: `${theme.sizes.slideWidth}px`,
    height: `${theme.sizes.slideHeight}px`,
    position: 'relative',
    overflow: 'hidden',
    fontFamily: theme.fonts.body,
    color: theme.colors.text,
    backgroundColor: theme.colors.background,
    boxSizing: 'border-box',
    padding: theme.spacing.padding,
  });

  const titleStyle = toInlineStyle({
    fontSize: theme.sizes.titleSize,
    fontWeight: 'bold',
    color: theme.colors.primary,
    margin: '0',
    lineHeight: '1.3',
    fontFamily: theme.fonts.title,
  });

  const contentContainerStyle = toInlineStyle({
    marginTop: '40px',
  });

  const paragraphStyle = toInlineStyle({
    fontSize: theme.sizes.bodySize,
    color: theme.colors.text,
    lineHeight: '1.8',
    margin: '0',
    marginTop: '20px',
  });

  const contentArray = Array.isArray(content) ? content : [content];
  const paragraphsHTML = contentArray
    .map((p) => `<p style="${paragraphStyle}">${p}</p>`)
    .join('\n    ');

  let highlightHTML = '';
  if (highlight) {
    const highlightStyle = toInlineStyle({
      marginTop: '30px',
      padding: '20px 24px',
      backgroundColor: theme.colors.backgroundAlt,
      borderLeft: `4px solid ${theme.colors.accent}`,
      borderRadius: '0 8px 8px 0',
      fontSize: theme.sizes.bodySize,
      color: theme.colors.text,
      fontStyle: 'italic',
    });
    highlightHTML = `<div style="${highlightStyle}">${highlight}</div>`;
  }

  return `<section style="${slideStyle}">
  <h2 style="${titleStyle}">${title}</h2>
  <div style="${contentContainerStyle}">
    ${paragraphsHTML}
    ${highlightHTML}
  </div>
</section>`;
}

function parseStyle(styleString: string): React.CSSProperties {
  const styles: Record<string, string> = {};
  styleString.split(';').forEach((rule) => {
    const [key, value] = rule.split(':').map((s) => s.trim());
    if (key && value) {
      const camelKey = key.replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
      styles[camelKey] = value;
    }
  });
  return styles as React.CSSProperties;
}

export default TitleContentLayout;
