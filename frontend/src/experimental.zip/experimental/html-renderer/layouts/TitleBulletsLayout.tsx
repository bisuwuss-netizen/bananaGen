/**
 * 标题+要点布局组件
 */

import React from 'react';
import { TitleBulletsModel, ThemeConfig } from '../types/schema';
import {
  toInlineStyle,
  getBaseSlideStyle,
  getTitleStyle,
  getSubtitleStyle,
} from '../utils/styleHelper';

interface TitleBulletsLayoutProps {
  model: TitleBulletsModel;
  theme: ThemeConfig;
}

export const TitleBulletsLayout: React.FC<TitleBulletsLayoutProps> = ({ model, theme }) => {
  const { title, subtitle, bullets } = model;

  const slideStyle = toInlineStyle(getBaseSlideStyle(theme));
  const titleStyle = toInlineStyle(getTitleStyle(theme));
  const subtitleStyle = toInlineStyle(getSubtitleStyle(theme));

  const bulletsContainerStyle = toInlineStyle({
    marginTop: '40px',
    display: 'grid',
    gridTemplateColumns: bullets.length <= 3 ? 'repeat(auto-fit, minmax(300px, 1fr))' : 'repeat(2, 1fr)',
    gap: '24px',
  });

  return (
    <section style={parseStyle(slideStyle)}>
      <h2 style={parseStyle(titleStyle)}>{title}</h2>
      {subtitle && <p style={parseStyle(subtitleStyle)}>{subtitle}</p>}
      <div style={parseStyle(bulletsContainerStyle)}>
        {bullets.map((bullet, index) => (
          <BulletCard key={index} bullet={bullet} theme={theme} />
        ))}
      </div>
    </section>
  );
};

const BulletCard: React.FC<{
  bullet: { icon?: string; text: string; description?: string };
  theme: ThemeConfig;
}> = ({ bullet, theme }) => {
  const cardStyle = toInlineStyle({
    padding: '24px',
    backgroundColor: theme.colors.backgroundAlt,
    borderRadius: '12px',
    display: 'flex',
    alignItems: 'flex-start',
    gap: '16px',
  });

  const iconContainerStyle = toInlineStyle({
    width: '48px',
    height: '48px',
    borderRadius: '10px',
    backgroundColor: theme.colors.secondary,
    color: '#ffffff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '20px',
    flexShrink: '0',
  });

  const textContainerStyle = toInlineStyle({
    flex: '1',
  });

  const bulletTextStyle = toInlineStyle({
    fontSize: '20px',
    fontWeight: '600',
    color: theme.colors.text,
    margin: '0',
  });

  const descriptionStyle = toInlineStyle({
    fontSize: '16px',
    color: theme.colors.textLight,
    margin: '0',
    marginTop: '8px',
    lineHeight: '1.5',
  });

  return (
    <div style={parseStyle(cardStyle)}>
      <div style={parseStyle(iconContainerStyle)}>
        {bullet.icon ? (
          <i className={bullet.icon.startsWith('fa') ? bullet.icon : `fa ${bullet.icon}`} />
        ) : (
          <i className="fa fa-check" />
        )}
      </div>
      <div style={parseStyle(textContainerStyle)}>
        <p style={parseStyle(bulletTextStyle)}>{bullet.text}</p>
        {bullet.description && (
          <p style={parseStyle(descriptionStyle)}>{bullet.description}</p>
        )}
      </div>
    </div>
  );
};

export function renderTitleBulletsLayoutHTML(model: TitleBulletsModel, theme: ThemeConfig): string {
  const { title, subtitle, bullets } = model;

  const slideStyle = toInlineStyle({
    width: `${theme.sizes.slideWidth}px`,
    height: `${theme.sizes.slideHeight}px`,
    position: 'relative',
    overflow: 'hidden',
    fontFamily: theme.fonts.body,
    color: theme.colors.text,
    backgroundColor: theme.colors.background,
    boxSizing: 'border-box',
    padding: theme.spacing.padding,
  });

  const titleStyle = toInlineStyle({
    fontSize: theme.sizes.titleSize,
    fontWeight: 'bold',
    color: theme.colors.primary,
    margin: '0',
    lineHeight: '1.3',
    fontFamily: theme.fonts.title,
  });

  const subtitleStyle = toInlineStyle({
    fontSize: theme.sizes.subtitleSize,
    color: theme.colors.textLight,
    margin: '0',
    marginTop: '12px',
    lineHeight: '1.4',
  });

  const bulletsContainerStyle = toInlineStyle({
    marginTop: '40px',
    display: 'grid',
    gridTemplateColumns: bullets.length <= 3 ? 'repeat(auto-fit, minmax(300px, 1fr))' : 'repeat(2, 1fr)',
    gap: '24px',
  });

  const bulletsHTML = bullets
    .map((bullet) => {
      const cardStyle = toInlineStyle({
        padding: '24px',
        backgroundColor: theme.colors.backgroundAlt,
        borderRadius: '12px',
        display: 'flex',
        alignItems: 'flex-start',
        gap: '16px',
      });

      const iconContainerStyle = toInlineStyle({
        width: '48px',
        height: '48px',
        borderRadius: '10px',
        backgroundColor: theme.colors.secondary,
        color: '#ffffff',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '20px',
        flexShrink: '0',
      });

      const textContainerStyle = toInlineStyle({
        flex: '1',
      });

      const bulletTextStyle = toInlineStyle({
        fontSize: '20px',
        fontWeight: '600',
        color: theme.colors.text,
        margin: '0',
      });

      const descriptionStyle = toInlineStyle({
        fontSize: '16px',
        color: theme.colors.textLight,
        margin: '0',
        marginTop: '8px',
        lineHeight: '1.5',
      });

      const iconClass = bullet.icon
        ? bullet.icon.startsWith('fa') ? bullet.icon : `fa ${bullet.icon}`
        : 'fa fa-check';

      return `<div style="${cardStyle}">
      <div style="${iconContainerStyle}">
        <i class="${iconClass}"></i>
      </div>
      <div style="${textContainerStyle}">
        <p style="${bulletTextStyle}">${bullet.text}</p>
        ${bullet.description ? `<p style="${descriptionStyle}">${bullet.description}</p>` : ''}
      </div>
    </div>`;
    })
    .join('\n    ');

  return `<section style="${slideStyle}">
  <h2 style="${titleStyle}">${title}</h2>
  ${subtitle ? `<p style="${subtitleStyle}">${subtitle}</p>` : ''}
  <div style="${bulletsContainerStyle}">
    ${bulletsHTML}
  </div>
</section>`;
}

function parseStyle(styleString: string): React.CSSProperties {
  const styles: Record<string, string> = {};
  styleString.split(';').forEach((rule) => {
    const [key, value] = rule.split(':').map((s) => s.trim());
    if (key && value) {
      const camelKey = key.replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
      styles[camelKey] = value;
    }
  });
  return styles as React.CSSProperties;
}

export default TitleBulletsLayout;
