/**
 * 全图页布局组件
 */

import React from 'react';
import { ImageFullModel, ThemeConfig } from '../types/schema';
import {
  toInlineStyle,
  getBaseSlideStyle,
  getImagePlaceholderStyle,
} from '../utils/styleHelper';

interface ImageFullLayoutProps {
  model: ImageFullModel;
  theme: ThemeConfig;
}

export const ImageFullLayout: React.FC<ImageFullLayoutProps> = ({ model, theme }) => {
  const { title, image_src, image_alt, caption } = model;

  const slideStyle = toInlineStyle({
    ...getBaseSlideStyle(theme),
    padding: '40px',
    display: 'flex',
    flexDirection: 'column',
  });

  const titleStyle = toInlineStyle({
    fontSize: '36px',
    fontWeight: 'bold',
    color: theme.colors.primary,
    margin: '0',
    marginBottom: '20px',
    textAlign: 'center',
  });

  const imageContainerStyle = toInlineStyle({
    flex: '1',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  });

  const imageStyle = toInlineStyle({
    maxWidth: '100%',
    maxHeight: '100%',
    objectFit: 'contain',
    borderRadius: '8px',
    boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
  });

  const captionStyle = toInlineStyle({
    fontSize: '16px',
    color: theme.colors.textLight,
    textAlign: 'center',
    margin: '0',
    marginTop: '16px',
    fontStyle: 'italic',
  });

  return (
    <section style={parseStyle(slideStyle)}>
      {title && <h2 style={parseStyle(titleStyle)}>{title}</h2>}
      <div style={parseStyle(imageContainerStyle)}>
        {image_src ? (
          <img
            src={image_src}
            alt={image_alt || ''}
            style={parseStyle(imageStyle)}
          />
        ) : (
          <div style={parseStyle(toInlineStyle(getImagePlaceholderStyle('80%', '400px')))}>
            点击上传图片
          </div>
        )}
      </div>
      {caption && <p style={parseStyle(captionStyle)}>{caption}</p>}
    </section>
  );
};

export function renderImageFullLayoutHTML(model: ImageFullModel, theme: ThemeConfig): string {
  const { title, image_src, image_alt, caption } = model;

  const slideStyle = toInlineStyle({
    width: `${theme.sizes.slideWidth}px`,
    height: `${theme.sizes.slideHeight}px`,
    position: 'relative',
    overflow: 'hidden',
    fontFamily: theme.fonts.body,
    color: theme.colors.text,
    backgroundColor: theme.colors.background,
    boxSizing: 'border-box',
    padding: '40px',
    display: 'flex',
    flexDirection: 'column',
  });

  const titleStyle = toInlineStyle({
    fontSize: '36px',
    fontWeight: 'bold',
    color: theme.colors.primary,
    margin: '0',
    marginBottom: '20px',
    textAlign: 'center',
  });

  const imageContainerStyle = toInlineStyle({
    flex: '1',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  });

  const imageStyle = toInlineStyle({
    maxWidth: '100%',
    maxHeight: '100%',
    objectFit: 'contain',
    borderRadius: '8px',
    boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
  });

  const captionStyle = toInlineStyle({
    fontSize: '16px',
    color: theme.colors.textLight,
    textAlign: 'center',
    margin: '0',
    marginTop: '16px',
    fontStyle: 'italic',
  });

  let imageHTML = '';
  if (image_src) {
    imageHTML = `<img src="${image_src}" alt="${image_alt || ''}" style="${imageStyle}" />`;
  } else {
    const placeholderStyle = toInlineStyle(getImagePlaceholderStyle('80%', '400px'));
    imageHTML = `<div style="${placeholderStyle}">[图片占位]</div>`;
  }

  return `<section style="${slideStyle}">
  ${title ? `<h2 style="${titleStyle}">${title}</h2>` : ''}
  <div style="${imageContainerStyle}">
    ${imageHTML}
  </div>
  ${caption ? `<p style="${captionStyle}">${caption}</p>` : ''}
</section>`;
}

function parseStyle(styleString: string): React.CSSProperties {
  const styles: Record<string, string> = {};
  styleString.split(';').forEach((rule) => {
    const [key, value] = rule.split(':').map((s) => s.trim());
    if (key && value) {
      const camelKey = key.replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
      styles[camelKey] = value;
    }
  });
  return styles as React.CSSProperties;
}

export default ImageFullLayout;
