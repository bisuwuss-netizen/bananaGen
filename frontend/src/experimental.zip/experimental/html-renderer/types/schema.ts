/**
 * HTML渲染器 Schema 类型定义
 * 基于反向约束架构设计
 */

// ==================== 全局配置 ====================

export interface PPTMeta {
  title: string;
  theme_id: string;
  aspect_ratio: '16:9' | '4:3';
  author?: string;
}

export interface PPTDocument {
  project_id: string;
  ppt_meta: PPTMeta;
  pages: PagePayload[];
}

// ==================== 页面配置 ====================

export interface PagePayload {
  page_id: string;
  order_index: number;
  layout_id: LayoutId;
  model: LayoutModel;
}

// 布局ID枚举
export type LayoutId =
  | 'cover'           // 封面页
  | 'toc'             // 目录页
  | 'title_content'   // 标题+正文
  | 'title_bullets'   // 标题+要点
  | 'two_column'      // 左右双栏
  | 'process_steps'   // 流程步骤
  | 'ending'          // 结束页
  | 'section_title'   // 章节标题页
  | 'image_full'      // 全图页
  | 'quote';          // 引用页

// 布局Model联合类型
export type LayoutModel =
  | CoverModel
  | TocModel
  | TitleContentModel
  | TitleBulletsModel
  | TwoColumnModel
  | ProcessStepsModel
  | EndingModel
  | SectionTitleModel
  | ImageFullModel
  | QuoteModel;

// ==================== 各布局Model定义 ====================

/** 封面页 */
export interface CoverModel {
  title: string;
  subtitle?: string;
  author?: string;
  department?: string;
  date?: string;
  background_image?: string;
}

/** 目录页 */
export interface TocModel {
  title: string;
  items: {
    index: number;
    text: string;
  }[];
}

/** 标题+正文 */
export interface TitleContentModel {
  title: string;
  content: string | string[];
  highlight?: string;
}

/** 标题+要点 */
export interface TitleBulletsModel {
  title: string;
  subtitle?: string;
  bullets: {
    icon?: string;
    text: string;
    description?: string;
  }[];
}

/** 左右双栏 */
export interface TwoColumnModel {
  title: string;
  left: ColumnContent;
  right: ColumnContent;
}

export interface ColumnContent {
  type: 'text' | 'image' | 'bullets';
  header?: string;
  content?: string | string[];
  image_src?: string;
  image_alt?: string;
  bullets?: {
    icon?: string;
    text: string;
  }[];
}

/** 流程步骤 */
export interface ProcessStepsModel {
  title: string;
  subtitle?: string;
  steps: {
    number: number;
    label: string;
    description?: string;
    icon?: string;
  }[];
}

/** 结束页 */
export interface EndingModel {
  title: string;
  subtitle?: string;
  contact?: string;
  qrcode?: string;
}

/** 章节标题页 */
export interface SectionTitleModel {
  section_number: string | number;
  title: string;
  subtitle?: string;
}

/** 全图页 */
export interface ImageFullModel {
  title?: string;
  image_src: string;
  image_alt?: string;
  caption?: string;
}

/** 引用页 */
export interface QuoteModel {
  quote: string;
  author?: string;
  source?: string;
}

// ==================== 主题类型 ====================

export interface ThemeConfig {
  id: string;
  name: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    text: string;
    textLight: string;
    background: string;
    backgroundAlt: string;
  };
  fonts: {
    title: string;
    body: string;
  };
  sizes: {
    slideWidth: number;
    slideHeight: number;
    titleSize: string;
    subtitleSize: string;
    bodySize: string;
    smallSize: string;
  };
  spacing: {
    padding: string;
    gap: string;
  };
}

// ==================== 图片资源类型 ====================

export interface ImageResource {
  id: string;
  type: 'placeholder' | 'uploaded' | 'generated';
  src: string;  // base64 或 URL
  alt?: string;
}
