/**
 * Tech Blue 主题配置
 * 适用于技术类/工程类教学PPT
 */

import { ThemeConfig } from '../types/schema';

export const techBlueTheme: ThemeConfig = {
  id: 'tech_blue',
  name: '科技蓝',
  colors: {
    primary: '#1a365d',       // 深蓝 - 标题/重点
    secondary: '#2b6cb0',     // 亮蓝 - 次要元素
    accent: '#ed8936',        // 橙色 - 强调/点缀
    text: '#2d3748',          // 深灰 - 正文
    textLight: '#718096',     // 浅灰 - 辅助文字
    background: '#ffffff',    // 白色 - 主背景
    backgroundAlt: '#f7fafc', // 浅灰 - 次要背景
  },
  fonts: {
    // 使用系统安全字体，确保跨平台兼容
    title: "'Microsoft YaHei', 'PingFang SC', 'Helvetica Neue', Arial, sans-serif",
    body: "'Microsoft YaHei', 'PingFang SC', 'Helvetica Neue', Arial, sans-serif",
  },
  sizes: {
    slideWidth: 1280,
    slideHeight: 720,
    titleSize: '44px',
    subtitleSize: '28px',
    bodySize: '22px',
    smallSize: '18px',
  },
  spacing: {
    padding: '60px',
    gap: '24px',
  },
};

/**
 * 生成渐变背景样式
 */
export function generateGradientBackground(
  startColor: string = techBlueTheme.colors.primary,
  endColor: string = techBlueTheme.colors.secondary,
  angle: number = 135
): string {
  return `linear-gradient(${angle}deg, ${startColor} 0%, ${endColor} 100%)`;
}

/**
 * 生成内联样式字符串
 * 将样式对象转换为内联样式字符串
 */
export function toInlineStyle(styles: Record<string, string | number>): string {
  return Object.entries(styles)
    .map(([key, value]) => {
      // 将 camelCase 转换为 kebab-case
      const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
      return `${cssKey}:${value}`;
    })
    .join('; ');
}

/**
 * 获取基础幻灯片容器样式
 */
export function getSlideContainerStyle(theme: ThemeConfig): string {
  return toInlineStyle({
    width: `${theme.sizes.slideWidth}px`,
    height: `${theme.sizes.slideHeight}px`,
    position: 'relative',
    overflow: 'hidden',
    fontFamily: theme.fonts.body,
    color: theme.colors.text,
    backgroundColor: theme.colors.background,
    boxSizing: 'border-box',
  });
}

export default techBlueTheme;
